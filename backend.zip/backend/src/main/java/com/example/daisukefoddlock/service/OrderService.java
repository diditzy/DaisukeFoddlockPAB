package com.example.daisukefoddlock.service;

import com.example.daisukefoddlock.dto.OrderRequest;
import com.example.daisukefoddlock.dto.OrderResponse;
import com.example.daisukefoddlock.entity.Order;
import com.example.daisukefoddlock.entity.User;
import com.example.daisukefoddlock.repository.OrderRepository;
import com.midtrans.service.MidtransSnapApi;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final MidtransSnapApi midtransSnapApi;

    @Transactional
    public OrderResponse createOrder(OrderRequest request, User customer) {
        // 1. Save order to database
        Order order = Order.builder()
                .customer(customer)
                .totalAmount(request.getTotalAmount())
                .status(Order.OrderStatus.PENDING)
                .build();
        
        order = orderRepository.save(order);

        // 2. Prepare Midtrans Snap Request
        Map<String, Object> params = new HashMap<>();

        Map<String, String> transactionDetails = new HashMap<>();
        // Use order ID combined with a unique string for Midtrans Order ID
        String midtransOrderId = "ORDER-" + order.getId() + "-" + UUID.randomUUID().toString().take(4);
        transactionDetails.put("order_id", midtransOrderId);
        transactionDetails.put("gross_amount", request.getTotalAmount().toPlainString());

        params.put("transaction_details", transactionDetails);

        // Optional: Add customer details
        Map<String, String> customerDetails = new HashMap<>();
        customerDetails.put("first_name", customer.getName());
        customerDetails.put("email", customer.getEmail());
        params.put("customer_details", customerDetails);

        try {
            // 3. Generate Snap Token
            String snapToken = midtransSnapApi.createTransactionToken(params);
            return OrderResponse.fromEntity(order, snapToken);
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate Midtrans Snap Token: " + e.getMessage());
        }
    }
}
