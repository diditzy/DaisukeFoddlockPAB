package com.example.daisukefoddlock.service;

import com.example.daisukefoddlock.dto.MidtransWebhookRequest;
import com.example.daisukefoddlock.entity.Order;
import com.example.daisukefoddlock.entity.Payment;
import com.example.daisukefoddlock.repository.OrderRepository;
import com.example.daisukefoddlock.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;

    @Value("${midtrans.server.key}")
    private String serverKey;

    @Transactional
    public void handleWebhook(MidtransWebhookRequest request) {
        // 1. Verify Signature Key
        if (!verifySignature(request)) {
            log.error("Invalid signature for order: {}", request.getOrderId());
            throw new RuntimeException("Invalid signature");
        }

        // 2. Parse Order ID (Format: ORDER-{id}-XXXX)
        String[] parts = request.getOrderId().split("-");
        if (parts.length < 2) {
            throw new RuntimeException("Invalid Order ID format");
        }
        Long orderId = Long.parseLong(parts[1]);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));

        // 3. Update or Create Payment record
        Payment payment = paymentRepository.findByOrder(order)
                .orElse(Payment.builder().order(order).build());

        payment.setMidtransTransactionId(request.getTransactionId());
        payment.setPaymentMethod(request.getPaymentType());
        
        String status = request.getTransactionStatus();
        updateStatuses(order, payment, status);

        paymentRepository.save(payment);
        orderRepository.save(order);
        
        log.info("Payment status updated for order {}: {}", orderId, status);
    }

    private void updateStatuses(Order order, Payment payment, String midtransStatus) {
        switch (midtransStatus) {
            case "settlement", "capture" -> {
                payment.setStatus(Payment.PaymentStatus.SETTLEMENT);
                payment.setPaidAt(LocalDateTime.now());
                order.setStatus(Order.OrderStatus.PAID);
            }
            case "pending" -> {
                payment.setStatus(Payment.PaymentStatus.PENDING);
                order.setStatus(Order.OrderStatus.PENDING);
            }
            case "deny", "cancel" -> {
                payment.setStatus(Payment.PaymentStatus.CANCEL);
                order.setStatus(Order.OrderStatus.CANCELLED);
            }
            case "expire" -> {
                payment.setStatus(Payment.PaymentStatus.EXPIRE);
                order.setStatus(Order.OrderStatus.EXPIRED);
            }
            default -> {
                payment.setStatus(Payment.PaymentStatus.FAILURE);
            }
        }
    }

    private boolean verifySignature(MidtransWebhookRequest request) {
        // SHA512(order_id + status_code + gross_amount + ServerKey)
        String raw = request.getOrderId() + request.getStatusCode() + request.getGrossAmount() + serverKey;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] digest = md.digest(raw.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString().equalsIgnoreCase(request.getSignatureKey());
        } catch (NoSuchAlgorithmException e) {
            return false;
        }
    }
}
