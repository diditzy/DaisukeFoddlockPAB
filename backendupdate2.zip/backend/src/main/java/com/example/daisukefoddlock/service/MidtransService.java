package com.example.daisukefoddlock.service;

import com.example.daisukefoddlock.dto.MidtransSnapRequest;
import com.example.daisukefoddlock.dto.MidtransSnapResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service
@RequiredArgsConstructor
@Slf4j
public class MidtransService {

    @Value("${midtrans.server-key}")
    private String serverKey;

    @Value("${midtrans.snap-url}")
    private String snapUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public MidtransSnapResponse getSnapToken(String orderId, Integer grossAmount, String email) {
        log.info("Requesting Midtrans Snap Token for orderId: {}, grossAmount: {}", orderId, grossAmount);

        // 1. Create request body
        MidtransSnapRequest requestBody = MidtransSnapRequest.builder()
                .transactionDetails(MidtransSnapRequest.TransactionDetails.builder()
                        .orderId(orderId)
                        .grossAmount(grossAmount)
                        .build())
                .customerDetails(MidtransSnapRequest.CustomerDetails.builder()
                        .email(email)
                        .build())
                .build();

        // 2. Prepare headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);

        // Authorization: Basic (Base64 of serverKey + ":")
        String authStr = serverKey + ":";
        String base64Auth = Base64.getEncoder().encodeToString(authStr.getBytes(StandardCharsets.UTF_8));
        headers.set("Authorization", "Basic " + base64Auth);

        HttpEntity<MidtransSnapRequest> request = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<MidtransSnapResponse> response = restTemplate.postForEntity(
                    snapUrl,
                    request,
                    MidtransSnapResponse.class
            );

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                log.info("Successfully received snap token for orderId: {}", orderId);
                return response.getBody();
            } else {
                log.error("Failed to fetch snap token: {}", response.getStatusCode());
                throw new RuntimeException("Midtrans API returned error status: " + response.getStatusCode());
            }
        } catch (Exception e) {
            log.error("Exception occurred while calling Midtrans Snap API for orderId: {}", orderId, e);
            throw new RuntimeException("Midtrans communication failure: " + e.getMessage());
        }
    }
}
