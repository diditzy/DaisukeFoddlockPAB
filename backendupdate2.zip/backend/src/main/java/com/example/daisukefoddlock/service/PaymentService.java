package com.example.daisukefoddlock.service;

import com.example.daisukefoddlock.dto.MidtransWebhookRequest;
import com.example.daisukefoddlock.entity.Order;
import com.example.daisukefoddlock.entity.Payment;
import com.example.daisukefoddlock.repository.OrderRepository;
import com.example.daisukefoddlock.repository.PaymentRepository;
import com.midtrans.service.MidtransCoreApi;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;
    private final MidtransCoreApi midtransCoreApi;

    @Transactional
    public void handleWebhook(MidtransWebhookRequest request) {
        log.info("Received webhook for Midtrans Order ID: {}", request.getOrderId());

        // 1. Find Order using externalOrderId (Standardized approach)
        Order order = orderRepository.findByExternalOrderId(request.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found: " + request.getOrderId()));

        // 2. Double Verification: Call Midtrans API to verify actual status
        // This is a production security best practice to prevent webhook spoofing
        try {
            Map<String, Object> statusResponse = midtransCoreApi.checkTransaction(request.getOrderId());
            String actualStatus = (String) statusResponse.get("transaction_status");
            String fraudStatus = (String) statusResponse.get("fraud_status");
            
            log.info("Verified status from Midtrans API: {} for order: {}", actualStatus, request.getOrderId());

            // 3. Update Payment record
            Payment payment = paymentRepository.findByOrder(order)
                    .orElse(Payment.builder().order(order).build());

            payment.setMidtransTransactionId((String) statusResponse.get("transaction_id"));
            payment.setPaymentMethod((String) statusResponse.get("payment_type"));
            payment.setMidtransStatus(actualStatus);
            
            // 4. Map Midtrans Status to Business Status
            mapAndApplyStatus(order, payment, actualStatus, fraudStatus);

            paymentRepository.save(payment);
            orderRepository.save(order);
            
        } catch (Exception e) {
            log.error("Failed to verify transaction with Midtrans API: {}", e.getMessage());
            throw new RuntimeException("Payment verification failed", e);
        }
    }

    /**
     * Maps Midtrans specific statuses to simplified internal business statuses.
     */
    private void mapAndApplyStatus(Order order, Payment payment, String midtransStatus, String fraudStatus) {
        switch (midtransStatus) {
            case "capture" -> {
                if ("challenge".equals(fraudStatus)) {
                    // Fraud detection triggered, need manual review but we'll treat as pending for now
                    applyStatus(order, payment, Payment.PaymentStatus.PENDING, Order.OrderStatus.PENDING);
                } else {
                    applyStatus(order, payment, Payment.PaymentStatus.PAID, Order.OrderStatus.PAID);
                    payment.setPaidAt(LocalDateTime.now());
                }
            }
            case "settlement" -> {
                applyStatus(order, payment, Payment.PaymentStatus.PAID, Order.OrderStatus.PAID);
                payment.setPaidAt(LocalDateTime.now());
            }
            case "pending" -> {
                applyStatus(order, payment, Payment.PaymentStatus.PENDING, Order.OrderStatus.PENDING);
            }
            case "deny", "cancel", "failure" -> {
                applyStatus(order, payment, Payment.PaymentStatus.FAILED, Order.OrderStatus.FAILED);
                order.setStatus(Order.OrderStatus.CANCELLED);
            }
            case "expire" -> {
                applyStatus(order, payment, Payment.PaymentStatus.EXPIRED, Order.OrderStatus.EXPIRED);
            }
            case "refund" -> {
                applyStatus(order, payment, Payment.PaymentStatus.REFUNDED, Order.OrderStatus.PENDING); // Business status usually stays pending or special status
            }
            default -> {
                log.warn("Unknown Midtrans status: {}", midtransStatus);
            }
        }
    }

    private void applyStatus(Order order, Payment payment, Payment.PaymentStatus pStatus, Order.OrderStatus oStatus) {
        payment.setStatus(pStatus);
        order.setStatus(oStatus);
    }
}
